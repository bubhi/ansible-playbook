
# CRC Lab Support Team |  Ansible Playbooks

## Summary
This repository contains all of the files needed to manage linux endpoints in the VPNL lab using Ansible. Many of the playbooks and roles are lab-agnostic, and can be applied to other labs with little to no modification. 

## Quick Start
To make use of this repository, you'll have to complete the following prerequisites:

- Obtain a secure, modern linux workstation (Debian, RHEL, or CENTOS Stream)
-- At least 4GB of RAM
-- At least 4 CPUs
-- 1Gb/s Wired Network Connection
-- (Recommended) Static IP Address
- A SSH key pair whose public key is propogated across all supported workstations. Your public key should be present in `/root/.ssh/authorized_keys` as well as `/YOUR/HOME/FOLDER/.ssh/authorized_keys`

### Install Ansible
For best results, use the offical ansible install instructions - https://docs.ansible.com/ansible/latest/installation_guide/intro_installation.html#installing-ansible-on-specific-operating-systems

### Update Hosts and config Files
Ansible has a few special files that allow it to know who to target when you're taking an action. Your list of hosts is in a file located at `/etc/ansible/hosts`. Configuration items for your global ansible install are available in `/etc/ansible/ansible.cfg`. The `config` directory in this repository is where you'll find sample files that should help you get started.

### Try your first command
Once you-ve completed the prerequisites, installed ansible, and copied the requisite `hosts` and `ansible.cfg` files, you're ready to run your first command! 

With great power, comes great responsibility, so let's start small:
- Use the `ping` module to check if a computer is online: `ansible ojo -m ping`
- This command checks to see if the computer is online and accpeting your connection. If it works, try pinging the entire lab: `ansible kgs -m ping` 

Targeting the whole lab with `kgs` works because your `hosts` file is set up to add each individual named host to a group called `kgs`. Check out `config/hosts` to see for yourself!

### Learn More About Ansible
Here are a few resources I can recommend that I have personally used and found very helpful:

- Jeff Geerling is far and away the best Ansible resource I've found. Here are a few resources that could help get you started. 
- This is the first video I watched when learning Ansible. It's a fantastic overview, and serves as a perfect quickstart. It uses a raspberry pi cluster as an example, but everything you see here is still applicable : https://youtu.be/ZNB1at8mJWY
- A more detailed article that includes this video can be found here - https://www.jeffgeerling.com/blog/ansible-101-cluster-raspberry-pi-2s
- Jeff also offers a book on Ansible administration that is available here -https://www.ansiblefordevops.com/
- Ansible uses `modules` to accomplish tasks. The web documetnation for Ansible modules is an invaluable resource to help you understand how to create your own actions and may help you better understand how some of my content works. You can learn more about modules here -https://docs.ansible.com/ansible/2.9/modules/modules_by_category.html

### Things to Keep in Mind
Configuration management tools like Ansible are incredibly powerful, and can also be incredibly dangerous in inexperienced, inattentive, or malicious hands. Never configure a computer to send ansible commands that does not follow stringent security standards. If you're ever in doubt, contact the Stanford Information Security Office for guidance before setting anything up. There is no "Undo" button, so choose your commands wisely and sparingly. 

Before sending any command for the first time, make it a habit to talk through what you are doing and what you expect the outcome to be. 
Create endpoints that you can test with and use these as targets for content that is new or unfamiliar to you. Your sequence of deployment should be as follows (note, only proceed to the next item if the previous one was completed without incident):
- Talk out what you expect to happen and how you can validate that outcome
- Send the content to a single development machine
- Send the content to a single production machine
- Send the content to a group of development machines
- Send the content to a group of production machines
